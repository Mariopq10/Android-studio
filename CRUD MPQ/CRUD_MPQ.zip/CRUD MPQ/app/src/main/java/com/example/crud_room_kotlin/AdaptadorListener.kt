package com.example.crud_room_kotlin

interface AdaptadorListener {
    fun onEditItemClick(usuario: Usuario)
    fun onDeleteItemClick(usuario: Usuario)
}