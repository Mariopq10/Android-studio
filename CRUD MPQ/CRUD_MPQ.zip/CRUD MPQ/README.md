# CRUD-Room-Kotlin-Android-Studio

Ejemplo sencillo de como implementar un CRUD con Room en Kotlin y Android Studio
